let e=null,r=!1;chrome.runtime.onMessage.addListener(t=>{t.type==="MEETING_DETECTED"&&a(t.payload.title)});async function a(t){if(!r&&!e){try{const i=await chrome.runtime.sendMessage({type:"GET_RECORDING_STATUS"});if(i!=null&&i.isRecording)return}catch{}s(t)}}function s(t){var i,o;if(e=document.createElement("div"),e.id="ai-meeting-recorder-prompt",e.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 9999999;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    background: rgba(253, 252, 249, 0.98);
    backdrop-filter: blur(16px);
    border: 1px solid #e5e3d9;
    border-radius: 12px;
    padding: 16px 20px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    color: #2d2d2d;
    max-width: 360px;
    display: flex;
    flex-direction: column;
    gap: 12px;
    animation: aiSlideIn 0.3s cubic-bezier(0.16, 1, 0.3, 1);
  `,!document.getElementById("ai-notetaker-styles")){const n=document.createElement("style");n.id="ai-notetaker-styles",n.textContent=`
      @keyframes aiSlideIn {
        from { transform: translateY(-30px); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
      }
      @keyframes aiPulseReady {
        0%, 100% { transform: scale(1); opacity: 1; }
        50% { transform: scale(1.15); opacity: 0.7; }
      }
    `,document.head.appendChild(n)}e.innerHTML=`
    <div style="display: flex; align-items: center; gap: 10px;">
      <div style="width: 10px; height: 10px; border-radius: 50%; background: #5b695e; box-shadow: 0 0 8px rgba(91,105,94,0.4); animation: aiPulseReady 2s infinite;"></div>
      <div style="flex: 1;">
        <div style="font-size: 14px; font-weight: 600; color: #1a1a1a;">Meeting Detected</div>
        <div style="font-size: 12px; color: #888; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${l(t||"Active Call")}</div>
      </div>
    </div>
    <div style="font-size: 13px; color: #555; line-height: 1.4;">
      Would you like to start the AI Notetaker to record and transcribe this meeting?
    </div>
    <div style="display: flex; justify-content: flex-end; gap: 8px; margin-top: 4px;">
      <button id="ai-btn-dismiss" style="background: #f2f0e9; border: 1px solid #e5e3d9; color: #666; padding: 8px 14px; border-radius: 4px; font-size: 12px; cursor: pointer; font-weight: 500;">
        Dismiss
      </button>
      <button id="ai-btn-record" style="background: #2d2d2d; border: 1px solid #2d2d2d; color: #ffffff; padding: 8px 16px; border-radius: 4px; font-size: 12px; cursor: pointer; font-weight: 500;">
        Start Recording
      </button>
    </div>
  `,document.body.appendChild(e),(i=document.getElementById("ai-btn-dismiss"))==null||i.addEventListener("click",()=>{r=!0,d()}),(o=document.getElementById("ai-btn-record"))==null||o.addEventListener("click",()=>{r=!0,chrome.runtime.sendMessage({type:"START_RECORDING"}),e&&(e.innerHTML=`
        <div style="display: flex; align-items: center; gap: 10px;">
          <div style="width: 10px; height: 10px; border-radius: 50%; background: #d97757; box-shadow: 0 0 8px rgba(217,119,87,0.4); animation: aiPulseReady 1.2s infinite;"></div>
          <div style="font-size: 14px; font-weight: 600; color: #d97757;">Recording In Progress...</div>
        </div>
        <div style="font-size: 12px; color: #888; margin-top: 4px;">Click the extension icon at any time to stop and transcribe.</div>
      `,setTimeout(d,3e3))})}function d(){e&&(e.remove(),e=null)}function l(t){const i={"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"};return t.replace(/[&<>'"]/g,o=>i[o]||o)}
