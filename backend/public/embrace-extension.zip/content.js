let e=null,d=!1,s=!1;setInterval(()=>{const n=location.href.includes("meet.google.com"),i=location.href.includes("teams.microsoft.com")||location.href.includes("teams.live.com")||location.href.includes("teams.cloud.microsoft");if(!n&&!i)return;const o=l();if(o&&!s){s=!0,d=!1;const t=n?"Google Meet":"Teams Call";c(document.title||t)}else!o&&s&&(s=!1)},2e3);function l(){var o;const n=['[aria-label*="Leave"]','[title*="Leave"]','[data-tid*="leave"]','[aria-label*="Hang up"]','[title*="Hang up"]',"button#hangup-button"];for(const t of n)if(document.querySelector(t))return!0;const i=document.querySelectorAll("button");for(let t=0;t<Math.min(i.length,50);t++){const r=(o=i[t].textContent)==null?void 0:o.toLowerCase();if(r!=null&&r.includes("leave")||r!=null&&r.includes("calling..."))return!0}return!1}async function c(n){if(!d&&!e){try{const i=await chrome.runtime.sendMessage({type:"GET_RECORDING_STATUS"});if(i!=null&&i.isRecording)return}catch{}p(n)}}function p(n){var i,o;if(e=document.createElement("div"),e.id="ai-meeting-recorder-prompt",e.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 9999999;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    background: rgba(253, 252, 249, 0.98);
    backdrop-filter: blur(16px);
    border: 1px solid #e5e3d9;
    border-radius: 12px;
    padding: 16px 20px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    color: #2d2d2d;
    max-width: 360px;
    display: flex;
    flex-direction: column;
    gap: 12px;
    animation: aiSlideIn 0.3s cubic-bezier(0.16, 1, 0.3, 1);
  `,!document.getElementById("ai-notetaker-styles")){const t=document.createElement("style");t.id="ai-notetaker-styles",t.textContent=`
      @keyframes aiSlideIn {
        from { transform: translateY(-30px); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
      }
      @keyframes aiPulseReady {
        0%, 100% { transform: scale(1); opacity: 1; }
        50% { transform: scale(1.15); opacity: 0.7; }
      }
    `,document.head.appendChild(t)}e.innerHTML=`
    <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 4px;">
      <div style="width: 10px; height: 10px; border-radius: 50%; background: #5b695e; box-shadow: 0 0 8px rgba(91,105,94,0.4); animation: aiPulseReady 2s infinite;"></div>
      <div style="flex: 1; min-width: 0;">
        <div style="font-size: 14px; font-weight: 600; color: #1a1a1a;">Meeting Detected</div>
        <div style="font-size: 12px; color: #888; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${u(n)}</div>
      </div>
    </div>
    <div style="font-size: 13px; color: #555; line-height: 1.5; margin-bottom: 12px;">
      Would you like to start the AI Notetaker to record and transcribe this meeting?
    </div>
    <div style="display: flex; justify-content: flex-end; gap: 8px;">
      <button id="ai-btn-dismiss" style="background: #f2f0e9; border: 1px solid #e5e3d9; color: #666; padding: 8px 14px; border-radius: 6px; font-size: 12px; cursor: pointer; font-weight: 500; transition: all 0.2s;" onmouseover="this.style.background='#e5e3d9'" onmouseout="this.style.background='#f2f0e9'">
        Dismiss
      </button>
      <button id="ai-btn-record" style="background: #2d2d2d; border: 1px solid #2d2d2d; color: #ffffff; padding: 8px 16px; border-radius: 6px; font-size: 12px; cursor: pointer; font-weight: 500; transition: all 0.2s;" onmouseover="this.style.background='#1a1a1a'" onmouseout="this.style.background='#2d2d2d'">
        Start Recording
      </button>
    </div>
  `,document.body.appendChild(e),(i=document.getElementById("ai-btn-dismiss"))==null||i.addEventListener("click",()=>{d=!0,a()}),(o=document.getElementById("ai-btn-record"))==null||o.addEventListener("click",()=>{d=!0,e&&(e.innerHTML=`
        <div style="display: flex; align-items: center; gap: 10px;">
          <div style="width: 10px; height: 10px; border-radius: 50%; background: #e5e3d9; box-shadow: 0 0 8px rgba(0,0,0,0.1); animation: aiPulseReady 1.2s infinite;"></div>
          <div style="font-size: 14px; font-weight: 600; color: #555;">Starting...</div>
        </div>
      `),chrome.runtime.sendMessage({type:"START_RECORDING"},t=>{var r;t&&t.success?e&&(e.innerHTML=`
            <div style="display: flex; align-items: center; gap: 10px;">
              <div style="width: 10px; height: 10px; border-radius: 50%; background: #d97757; box-shadow: 0 0 8px rgba(217,119,87,0.4); animation: aiPulseReady 1.2s infinite;"></div>
              <div style="font-size: 14px; font-weight: 600; color: #d97757;">Recording In Progress...</div>
            </div>
            <div style="font-size: 12px; color: #888; margin-top: 4px;">Click the extension icon at any time to stop and transcribe.</div>
          `,setTimeout(a,3e3)):e&&(e.innerHTML=`
            <div style="display: flex; align-items: center; gap: 10px;">
              <div style="font-size: 14px; font-weight: 600; color: #da7756;">Permission Required</div>
            </div>
            <div style="font-size: 13px; color: #555; margin-top: 4px; line-height: 1.4;">
              Chrome requires you to click the <strong>AI Notetaker extension icon</strong> in your browser toolbar to start recording.
            </div>
            <div style="display: flex; justify-content: flex-end; gap: 8px; margin-top: 4px;">
              <button id="ai-btn-close-error" style="background: #f2f0e9; border: 1px solid #e5e3d9; color: #666; padding: 8px 14px; border-radius: 4px; font-size: 12px; cursor: pointer; font-weight: 500;">
                Got it
              </button>
            </div>
          `,(r=document.getElementById("ai-btn-close-error"))==null||r.addEventListener("click",a))})})}function a(){e&&(e.remove(),e=null)}function u(n){const i={"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"};return n.replace(/[&<>'"]/g,o=>i[o]||o)}
